
#!/usr/bin/python
# -*- coding: utf-8 -*-
'''
Testing arguments for scripts
'''
import os
import sys
import getopt


if __name__ == "__main__":
    # Задаём формат входных параметров
    unixOptions = "f:e:"  
    gnuOptions = ["file=",'eval=']
    # Получаем строку входных параметров
    fullCmdArguments = sys.argv
    argumentList = fullCmdArguments[1:]

    # Проверяем входные параметры на соответствие формату,
    # заданному в unixOptions и gnuOptions
    try:  
        arguments, values = getopt.getopt(argumentList, unixOptions, gnuOptions)
    except getopt.error as err:  
        print (str(err))
        sys.exit(2)      

    # Считываем значения из строки входных параметров
    file = ''
    
       
    for currentArgument, currentValue in arguments:  
        if currentArgument in ("-f", "--file"):
            file = currentValue                     
        if currentArgument in ("-e", "--eval"):
            evalue = float(currentValue)
    print(type(file))
    print(type(evalue))

    