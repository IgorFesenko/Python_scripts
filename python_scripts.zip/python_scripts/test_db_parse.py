from Bio.Alphabet import IUPAC
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq
from Bio import SeqIO
import pandas as pd
import re



db2 = r"C:\Users\fesenkoi2\IFESENKO\orthologs\merged_conifers.fa"


#dict_db2 = SeqIO.index(db2, "fasta")

#print(dict_db2[' scaffold-QNGJ-2001487-Cupressus_dupreziana'].seq)
"""for i in dict_db2.items():
    if 'scaffold-QNGJ-2001487-Cupressus_dupreziana' in i.id:

        
        print(i)
"""
for record in SeqIO.parse(db2, 'fasta'):
    if re.findall(pattern=r'scaffold-QNGJ-2001487-Cupressus_dupreziana', string=record.id):
        print(record.id)
        print('scaffold-QNGJ-2001487-Cupressus_dupreziana')
