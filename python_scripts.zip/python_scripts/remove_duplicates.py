from Bio import SeqIO
from Bio.SeqRecord import SeqRecord

# read file
file_input = r"C:\Users\fesenkoi2\IFESENKO\orthologs\sORFs_mipepid_nucleotide.fasta"

# out file
records = []
out_file = r"C:\Users\fesenkoi2\IFESENKO\orthologs\sORFs_mipepid_nucleotide_nonduplicates.fasta"
# names list
names=set()

for record in SeqIO.parse(file_input, 'fasta'):
    
    if record.id in names:
        continue
        
    else:
        names.add(record.id)
        records.append(SeqRecord(seq=record.seq, id=record.id, description=record.description))



SeqIO.write(records,out_file,"fasta")



