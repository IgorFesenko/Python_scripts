import requests
from bs4 import BeautifulSoup
import re


# reading the list of species
with open (r"C:\Users\fesenkoi2\IFESENKO\1000_transcriptomes\Hornworts.txt") as input_lst:
    names = [i.strip() for i in input_lst.readlines()]

print(f'The number of species:{len(names)}')
print()

for name in names:
    print(name)
    URL = r'https://data.cyverse.org/dav-anon/iplant/projects/commons_repo/curated/oneKP_capstone_2019/transcript_assemblies/{}/'.format(name)
    print(URL)
    req = requests.get(URL)
    try:
        soup = BeautifulSoup(req.text, 'html.parser')
        files = [URL + '/' + node.get('href') for node in soup.find_all('a')]
        for i in files:
            if re.findall('Trans-assembly', i):
                myfile = requests.get(i)
                print(myfile)
                print()
                open (r'C:\Users\fesenkoi2\IFESENKO\1000_transcriptomes\Hornworts\{}.fa.bz2'.format(name), 'wb').write(myfile.content)
    except:
        print('ERROR')
        