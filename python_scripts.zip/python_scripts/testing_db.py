from Bio import SeqIO

file1 = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_mipepid\combined_sORFs_mipepid_locus_transcripts_nonredundant.fasta"

file2 = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_mipepid\combined_sORFs_mipepid_locus_transcripts_nonredundant_nonested.fasta"

file_filt = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_mipepid\nested_combined_sORFs_mipepid.txt"

def lst_id(file):
    lst = set()
    for record in SeqIO.parse(file, 'fasta'):
        lst.add(record.id)
    return lst


with open(file_filt) as inp:
    lst = set([i.strip().split(' ')[0] for i in inp.readlines()])

print(len(lst))

mipepid_filt = lst_id(file2)

mipepid_nonfilt = lst_id(file1)

diff = mipepid_nonfilt-mipepid_filt
print(len(diff))

cnt=0
for i in lst-diff:
    cnt+=1
    print(i)

print(cnt)