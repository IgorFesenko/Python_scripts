# составляем fasta lncRNAs NCBI c последовательностями, обозначенными как ncRNAs

from Bio import SeqIO
import re
from Bio.SeqRecord import SeqRecord

# input file
file_input = r'/Users/igorfesenko/Google Диск/lncRNAs_sORFs/NCBI_lncRNAs/moss_ncbi_lncrnas.fa'

# out file
records = []
out_file = r'/Users/igorfesenko/Google Диск/lncRNAs_sORFs/NCBI_lncRNAs/moss_ncbi_lncrnas_filt.fasta'

for record in SeqIO.parse(file_input, 'fasta'):
    if re.findall(pattern='ncRNA', string=record.description):
        records.append(SeqRecord(seq=record.seq, id=record.id, description=record.description))

SeqIO.write(records,out_file,"fasta")
