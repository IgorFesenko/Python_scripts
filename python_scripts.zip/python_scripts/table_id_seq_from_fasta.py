"""
Scripts extacts sequence and if from fasta and return a table
"""
from Bio import SeqIO
import pandas as pd

input_fasta = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\combined_set\merged_lncRNAs_locuses_above200_filtered.fasta"

table_list = []

for record in SeqIO.parse(input_fasta, 'fasta'):
    table_list.append([record.id, record.seq])

df = pd.DataFrame(columns=['id_name', 'sequence'], data=table_list)

df.to_csv(r'C:\Users\fesenkoi2\IFESENKO\orthologs\table_seq_locuses.csv', index=False)