# Searching for NCBI finder sORFs nested in MiPepid new database

from Bio import SeqIO
import re


db_file1 = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_mipepid\combined_sORFs_mipepid_locus_transcripts_nonredundant_nonested.fasta"

db_file2 = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_NCBIfinder\merged_sORFs_NCBIfinder_locus_transcripts_nonredundant_filt_agaisnt_mipepid_nonested.fa"

dict_db = {}

for record in SeqIO.parse(db_file2, 'fasta'):
    dict_db[str(record.seq)]=record.id


cnt=0
cntn=0    
for record in SeqIO.parse(db_file1, 'fasta'):
    cnt+=1
    print("sORF: {}".format(cnt))
    search_space = {k:v for k,v in dict_db.items() if len(k)>len(record.seq)}
    #print(search_space.keys())
    for k,v in search_space.items():
        if re.findall(str(record.seq), k):
            cntn+=1
            print("nested: {}".format(cntn))
            with open (r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_NCBIfinder\nestedNCBIfinder_in_mipepid.txt", 'a') as out_names:
                out_names.write("{} {}".format(record.id,v)+'\n')
            #print(record.seq, 'in', k)
print()
print(f"The number of nested sORFs: {cntn}")