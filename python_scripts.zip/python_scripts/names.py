"""
Rewriting fasta database with new names
"""

from Bio import SeqIO
from Bio.SeqRecord import SeqRecord

db_input = r"C:\Users\fesenkoi2\IFESENKO\signalP\combined_sORFs_signalP_sorfs.fasta"

table_names = r"C:\Users\fesenkoi2\IFESENKO\signalP\combined_sORFs_signalP_sorfs_names.txt"

out_file = r"C:\Users\fesenkoi2\IFESENKO\signalP\combined_sORFs_signalP_sorfs_newnames.fasta"

name=0
records = []

with open(table_names, 'a') as out:    
    for record in SeqIO.parse(db_input, 'fasta'):
        name+=1
        #print("sORF: {}".format(name))
        name_id = "sORF_{}".format(name)
        records.append(SeqRecord(seq=record.seq, id=name_id, description=record.id))
        out.write("{} {}\n".format(name_id, record.id))
  

SeqIO.write(records,out_file,"fasta")