from Bio import SeqIO
from Bio.Seq import Seq
from Bio.Alphabet import IUPAC
from Bio.SeqRecord import SeqRecord


# Транслируем fasta базу данных


# read file
file_input = r"C:\Users\fesenkoi2\IFESENKO\sORFinder\Physcomitrella\moss_sORF_lncRNAs.fa"
out_file = r"C:\Users\fesenkoi2\IFESENKO\sORFinder\Physcomitrella\moss_sORF_lncRNAs_translation_redundant.fa"

records = []
sequences = set()
for record in SeqIO.parse(file_input, 'fasta'):
    records.append(SeqRecord(seq=record.seq.translate(), id=record.id, description=record.description))
    '''if record.seq not in sequences:
        records.append(SeqRecord(seq=record.seq.translate(), id=record.id, description=record.description))
        sequences.add(record.seq)
    else:
        continue'''

SeqIO.write(records,out_file,"fasta")