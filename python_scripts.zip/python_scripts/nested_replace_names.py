# Trying to replace names in nested sORFs

# read file
with open(r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_mipepid\nested_combined_sORFs_mipepid.txt") as inp_lst:
    lst = [i.strip().split(' ') for i in inp_lst.readlines()]

# creating dictionary
lst_dict = {k:v for k,v in lst}
print(len(lst_dict))



# replacing values in three iteration
for _ in range(4):

    for k,v in lst_dict.items():
        #print(k,v)
        try:
            value = lst_dict[v]
            lst_dict[k]=value
        except:
            continue

with open (r'C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_mipepid\nested_combined_sORFs_mipepid_for_table.txt', 'w') as output:
    for k,v in lst_dict.items():
         output.write("{} {}".format(k,v)+'\n')


