"""
Counting and changing IDs longer than 50 symbols (makeblastdb restriction)

"""

from Bio.Alphabet import IUPAC
from Bio.SeqRecord import SeqRecord
from Bio.Seq import Seq
from Bio import SeqIO
import pandas as pd
from time import process_time

t_start2 = process_time()

input_db = r"C:\Users\fesenkoi2\IFESENKO\1000_transcriptomes\Basal_Eudicots\basal_eudicots.fa"

output_db = r"C:\Users\fesenkoi2\IFESENKO\1000_transcriptomes\Basal_Eudicots\basal_eudicots_id.fa"

records = []

counter = 0
for record in SeqIO.parse(input_db, 'fasta'):
    records.append(SeqRecord(seq=record.seq, id=record.id[:49], description=record.description))

    if len(record.id)>50:
        counter+=1

print(counter)
SeqIO.write(records,output_db,"fasta")

t_stop2 = process_time()
print(f"TIME: {(t_stop2-t_start2)/60} min")