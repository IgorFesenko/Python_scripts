from Bio.Blast import NCBIXML
import pandas as pd



# path to BLAST results
out_file = r"C:\Users\fesenkoi2\IFESENKO\NCBI_BlastP\merged_sORFs_NCBIfinder_locus_transcripts_nonredundant_filt_agaisnt_mipepid_nonested_physco_proteome"

# path to alignment file
out_aligm = r"C:\Users\fesenkoi2\IFESENKO\NCBI_BlastP\merged_sORFs_NCBIfinder_locus_transcripts_nonredundant_filt_agaisnt_mipepid_nonested_physco_proteome_aligment.txt"

# create table
df = pd.DataFrame({'ID_query':[], 'query_length':[], 'Identities':[],'Aligments length':[], 'Hit length':[], 'Blast_hit':[], 'e_value':[], 'Score':[]})

cnt_all = set()
cnt_hom = set()


result_handle = open(out_file)
blast_records = NCBIXML.parse(result_handle)


with open(out_aligm, 'a') as out_file:
    for alignment in blast_records:
        query=alignment.query
        cnt_all.add(query)
        l=alignment.query_letters
        if (len(alignment.alignments))!=0:
            
            for hit in alignment.alignments:
                for hsp in hit.hsps:
                    p = hsp.identities
                    d = hit.length
                    c = hsp.align_length
                    e = hsp.expect
                    score=hsp.score
                    h=hit.title
                    if e<0.00001:# and c/l*100>=50: #p/d*100>=30:
                        cnt_hom.add(query)
                                            
                        out_file.write('****Alignment****'+'\n')
                        out_file.write('query: {}'.format(query)+'\n')
                        out_file.write('Blast_hit: {}'.format(h)+'\n')
                        out_file.write('e value: {}, Score: {}'.format(e, score)+'\n')
                        out_file.write('identities: {} length query: {} aligments length: {}'.format(p,l,c)+'\n')
                        out_file.write('Hit length: {}'.format(d)+'\n')
                        out_file.write(hsp.query[0:100] + '...'+'\n')
                        out_file.write(hsp.match[0:100] + '...'+'\n')
                        out_file.write(hsp.sbjct[0:100] + '...'+'\n')
                        out_file.write('\n')

                        df = df.append({'ID_query':query, 'query_length':l, 'Identities':p,'Aligments length':c, 'Hit length':d,'Blast_hit':hit, 'e_value':e, 'Score':score}, ignore_index=True)
                        
                    else:
                        
                        df = df.append({'ID_query':query, 'query_length':l, 'Identities':p,'Aligments length':c, 'Hit length':d,'Blast_hit':'No', 'e_value':'No', 'Score':'No'}, ignore_index=True)
        else:
            
            df = df.append({'ID_query':query, 'query_length':l, 'Identities':'No','Aligments length':'No', 'Hit length':'No','Blast_hit':'No', 'e_value':'No', 'Score':'No'}, ignore_index=True)


#print(df.head(20))
df.to_excel(r'C:\Users\fesenkoi2\IFESENKO\NCBI_BlastP\merged_sORFs_NCBIfinder_locus_transcripts_nonredundant_filt_agaisnt_mipepid_nonested_physco_proteome_eval00001.xlsx', index=False)

print(f"The number of lncRNAs: {len(cnt_all)}, pass_filter: {len(cnt_hom)}")