# фильтрация fasta по заданному списку

from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
import re

# read file
file_input = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\combined_set\cantata_greenc_paper__ncbi__rensing_transcripts.fasta"

# out file
records = []
out_file = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\combined_set\merged_lncRNAs_transcripts_filtered.fasta"

# names list
file_filt = r'C:\Users\fesenkoi2\IFESENKO\prot_lncRNAs_transcripts.txt'

with open(file_filt) as inp:
    lst = [i.strip() for i in inp.readlines()]

for record in SeqIO.parse(file_input, 'fasta'):
    name = record.id
    if name in lst:
        continue
    else:
        records.append(SeqRecord(seq=record.seq, id=name, description=record.description))
    

SeqIO.write(records,out_file,"fasta")