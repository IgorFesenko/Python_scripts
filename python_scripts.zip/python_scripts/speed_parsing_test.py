'''
The comparison of different parsing methods
'''

from Bio.Blast import NCBIXML
import pandas as pd
from time import process_time

test_file = r"C:\Users\fesenkoi2\IFESENKO\NCBI_BLASTX_TBLASTN\fragment_mipepid_for_tblastn.fasta.out5tblastn_mosses"
'''
print(f"The first method starting...")

t_start = process_time()

out_table = pd.DataFrame({'query':[],'hit':[],'Seq_query':[],'Seq_hit':[], 'Seq_query_nucl':[],'Seq_hit_nucl':[],'evalue':[],'query_start':[],'query_stop':[],'hit_start':[],'hit_stop':[],'frame':[],'align_len':[],'identities':[]})

result_handle = open(test_file)
blast_records = NCBIXML.parse(result_handle) 
 
for alignment in blast_records:
    query=alignment.query # ID of query
    # checking of possible alignment
    if (len(alignment.alignments))!=0:
        for hit in alignment.alignments:
            for hsp in hit.hsps:
                e = hsp.expect # e-value
                # Filtering results for output
                if e<0.001:
                    out_table = out_table.append({'query':query,'hit':hit.title,'Seq_query':hsp.query,'Seq_hit':hsp.sbjct, 'Seq_query_nucl':'-','Seq_hit_nucl':'-','evalue':e,'query_start':hsp.query_start,'query_stop':hsp.query_end,'hit_start':hsp.sbjct_start,'hit_stop':hsp.sbjct_end, 'frame':hsp.frame,'align_len':hsp.align_length,'identities':hsp.identities}, ignore_index=True)

t_stop = process_time()

print(f"TIME: {(t_stop-t_start)} sec")
print()
'''
print(f"The second method starting...")
t_start2 = process_time()

result_table=[]

result_handle2 = open(test_file)
blast_records2 = NCBIXML.parse(result_handle2) 
 
for alignment in blast_records2:
    query=alignment.query # ID of query
    # checking of possible alignment
    if (len(alignment.alignments))!=0:
        for hit in alignment.alignments:
            for hsp in hit.hsps:
                e = hsp.expect # e-value
                # Filtering results for output
                if e<0.001:
                    result_table.append([query,hit.title,hsp.query,hsp.sbjct,'-','-',e,hsp.query_start, hsp.query_end,hsp.sbjct_start,hsp.sbjct_end, hsp.frame, hsp.align_length,hsp.identities]) 
                 

t_stop2 = process_time()
print(f"TIME: {(t_stop2-t_start2)} sec")

df = pd.DataFrame(columns=['query','hit','Seq_query','Seq_hit', 'Seq_query_nucl','Seq_hit_nucl','evalue','query_start','query_stop','hit_start','hit_stop', 'frame','align_len','identities'], data=result_table)
print(df.head().style)
