# получаем список id из fasta files

from Bio import SeqIO

# read file
file_input = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\combined_set\merged_lncRNAs_transcripts_filtered)my_translation.fasta"

out_file = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\combined_set\merged_lncRNAs_transcripts_filtered)my_translation_id_len.txt"

names = set()
with open (out_file, 'a') as out:

    for record in SeqIO.parse(file_input, 'fasta'):
        out.write(f"{record.id} {len(record.seq)}\n")