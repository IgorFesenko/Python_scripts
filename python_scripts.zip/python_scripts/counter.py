# The number of coding and non-coding sORFs according to MiPepid

from Bio import SeqIO
import re

# read file
file_input = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\combined_sORFs_mipepid_locus_transcripts_nonredundant.fasta"

cnt1 = 0
cnt2 = 0

for record in SeqIO.parse(file_input, 'fasta'):
    cnt2+=1
    
    if re.findall('_noncoding',record.description):
        cnt1+=1
    
print(f"Coding: {cnt2-cnt1}, Non-coding: {cnt1}")