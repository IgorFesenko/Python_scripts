#!/usr/bin/python
# -*- coding: utf-8 -*-

import os
import sys
import getopt
from Bio.Blast import NCBIXML
import pandas as pd

if __name__ == "__main__":
    # Задаём формат входных параметров
    unixOptions = "f:"  
    gnuOptions = ["file="]
    # Получаем строку входных параметров
    fullCmdArguments = sys.argv
    argumentList = fullCmdArguments[1:]

    # Проверяем входные параметры на соответствие формату,
    # заданному в unixOptions и gnuOptions
    try:  
        arguments, values = getopt.getopt(argumentList, unixOptions, gnuOptions)
    except getopt.error as err:  
        print (str(err))
        sys.exit(2)      

    # Считываем значения из строки входных параметров
    file = ''
    
       
    for currentArgument, currentValue in arguments:  
        if currentArgument in ("-f", "--file"):
            file = currentValue                                   
        
    
    
    # path to alignment file
    out_aligm = r"{}_aligment.txt".format(file)

    # create table
    df = pd.DataFrame({'ID_query':[], 'query_length':[],'Aligments length':[], 'Hit length':[], 'Blast_hit':[], 'e_value':[], 'Score':[]})

    # parsing results
    result_handle = open(file)
    blast_records = NCBIXML.parse(result_handle)

    
    for alignment in blast_records:
        query=alignment.query # ID of query
        l=alignment.query_letters # the length of query
        # checking of possible alignment
        if (len(alignment.alignments))!=0:
                
            for hit in alignment.alignments: 
                for hsp in hit.hsps:
                        
                    p = hsp.identities # the number of identities
                    d = hit.length # hit length
                    c = hsp.align_length # alignments length
                    e = hsp.expect # e-value
                                        
                    # Filtering results for output
                    if e<0.00001: 
                        h=hit.title # Blast hit
                        score=hsp.score # Blast score
                   
                               
                        # add to output table
                        df = df.append({'ID_query':query, 'query_length':l,'Aligments length':c, 'Hit length':d,'Blast_hit':hit, 'e_value':e, 'Score':score}, ignore_index=True)
                            
                    else:
                         # add to output table
                        df = df.append({'ID_query':query, 'query_length':l,'Aligments length':c, 'Hit length':d,'Blast_hit':'No', 'e_value':e, 'Score':'No'}, ignore_index=True)
        else:
            continue
            # add to output table
            #df = df.append({'ID_query':query, 'query_length':l,'Aligments length':'No', 'Hit length':'No','Blast_hit':'No', 'e_value':'No', 'Score':'No'}, ignore_index=True)


    # writing output table
    df.to_csv(f"./{file}_evalue{10e5}.csv", index=False, compression='gzip')
