"""
Creating a table for NCBI finder
"""
import re
import datetime

b = datetime.datetime.now()

print(f"The program started at {b.strftime('%Y-%m-%d %H.%M')}")


def locus_name(row):
    patern = row.split('::')[0].replace('|','U')
    for locus in lst2:
        string = locus.split('::')[0].replace('|','U')
        if re.findall(pattern=patern, string=string):
            return locus
    return f'{row}_Not_found'
    print(row)


lncRNAs = r"C:\Users\fesenkoi2\Downloads\merged_lncRNAs_transcripts_names.txt"

locus = r"C:\Users\fesenkoi2\Downloads\merged_lncRNAs_locuses_names.txt"


with open(lncRNAs) as inp1:
    lst1 = [i.strip() for i in inp1.readlines()]

print(f"The number of lncRNAs: {len(lst1)}")

with open(locus) as inp1:
    lst2 = [i.strip() for i in inp1.readlines()]
print(f"The number of locuses: {len(lst2)}")

with open (r'C:\Users\fesenkoi2\Downloads\all_lncRNAs_locuses_2.txt','a') as out:
    for i in lst1:
        loc = locus_name(i)
        out.write(f"{i} {loc}\n")

then = datetime.datetime.now()
# Кол-во времени между датами.
print(f"The programm ended at: {then.strftime('%Y-%m-%d %H.%M')}")s
