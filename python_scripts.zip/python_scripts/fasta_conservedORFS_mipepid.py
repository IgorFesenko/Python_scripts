# Generating a database with new ID

from Bio import SeqIO
from Bio.SeqRecord import SeqRecord

db_input = r"C:\Users\fesenkoi2\IFESENKO\SPADA\spada_transcripts_translation.fasta"

table_names = r'C:\Users\fesenkoi2\IFESENKO\SPADA\new_names_spada.txt'

out_file = r"C:\Users\fesenkoi2\IFESENKO\SPADA\spada_transcripts_translation_new_names.fasta"

name=0
records = []

with open(table_names, 'a') as out:
    for record in SeqIO.parse(db_input, 'fasta'):
        name+=1
        #print("sORF: {}".format(name))
        name_id = "tr|ORF_{}|SPADA".format(name)
        records.append(SeqRecord(seq=record.seq, id=name_id))
        out.write("{} {}".format(name_id, record.id)+'\n')
    

SeqIO.write(records,out_file,"fasta")

#sp|Q9FLP0|MA651_ARATH