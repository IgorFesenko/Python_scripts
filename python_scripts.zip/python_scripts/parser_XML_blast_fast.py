# Parsing XML data


from Bio.Blast import NCBIXML
import pandas as pd
from time import process_time

EVALUE = 0.001

# path to BLAST results
out_file = r"C:\Users\fesenkoi2\IFESENKO\NCBI_BLASTX_TBLASTN\fragment_mipepid_for_tblastn.fasta.out5tblastn_mosses"

# create table
df = pd.DataFrame({'ID_query':[], 'query_length':[],'Aligments length':[], 'Identity':[],'Hit length':[], 'Blast_hit':[], 'e_value':[], 'Score':[]})

#counters
cnt_all = set()
cnt_hom = set()

# parsing results
result_handle = open(out_file)
blast_records = NCBIXML.parse(result_handle) 
results={}
print('START...')

t_start = process_time()

for alignment in blast_records:
    query=alignment.query # ID of query
    cnt_all.add(query) # count of records
    # checking of possible alignment
    if (len(alignment.alignments))>0:
        for hit in alignment.alignments: 
            for hsp in hit.hsps:
                e = hsp.expect # e-value
                # Filtering results for output
                if e<EVALUE:
                    cnt_hom.add(query)
                    
                    # add to output table
                    df = df.append({'ID_query':query, 'query_length':alignment.query_letters,'Aligments length':hsp.align_length, 'Identity':hsp.identities,'Hit length':hit.length,'Blast_hit':hit.title, 'e_value':e, 'Score':hsp.score}, ignore_index=True)
                        

t_stop = process_time()
# writing output table
print('WRITING...')
df.to_csv(r"C:\Users\fesenkoi2\IFESENKO\NCBI_BLASTX_TBLASTN\fragment_mipepid_for_tblastn_out5tblastn_mosses_evalue10e3.csv", index=False, compression='gzip')

print(f"The number of query: {len(cnt_all)}, passed the filter: {len(cnt_hom)}")
print(f"TIME: {(t_stop-t_start)/60} min")