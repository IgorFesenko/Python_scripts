# получаем список id из fasta files

from Bio import SeqIO

# read file
file_input = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_NCBIfinder\merged_sORFs_NCBIfinder_locus_transcripts_nonredundant_filt_agaisnt_mipepid_nonested.fa"

out_file = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_NCBIfinder\merged_sORFs_NCBIfinder_locus_transcripts_nonredundant_filt_agaisnt_mipepid_nonested_id.txt"

names = set()
with open (out_file, 'a') as out:

    for record in SeqIO.parse(file_input, 'fasta'):
        name = record.id#.split('|')[1]
        
        out.write(f"{name}\n")