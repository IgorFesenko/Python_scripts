# считаем количество sORFs заданной длины

from Bio import SeqIO

# input file
file_input = r'/Users/igorfesenko/Google Диск/lncRNAs_sORFs/all_sORFs_poteintial/sorfs_translation.fasta'

cnt=0
l = 70
for record in SeqIO.parse(file_input, 'fasta'):
    if len(record.seq)>l:
        cnt+=1
print(f"The number of sORFs above {l}aa is {cnt}")
