# remove N in sequences from database

from Bio import SeqIO
from Bio.SeqRecord import SeqRecord

# read file
file_input = r'/Users/igorfesenko/Google Диск/lncRNAs_sORFs/NCBI_lncRNAs/moss_ncbi_lncrnas_filt.fasta'

for record in SeqIO.parse(file_input, 'fasta'):
    if 'N' in record.seq:
        print(record.id)