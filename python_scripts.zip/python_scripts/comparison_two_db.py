# Compare two db and read new unique db

from Bio import SeqIO
from Bio.SeqRecord import SeqRecord


first_db = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_mipepid\combined_sORFs_mipepid_locus_transcripts_nonredundant.fasta"

second_db = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_NCBIfinder\merged_sORFs_NCBIfinder_locus_transcripts_nonredundant.fa"

out_db = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_NCBIfinder\merged_sORFs_NCBIfinder_locus_transcripts_nonredundant_filt_agaisnt_mipepid.fa"


first_db_seq = set()

for record in SeqIO.parse(first_db, 'fasta'):
    first_db_seq.add(record.seq[:-1])

print(f"The number of records in the first db: {len(first_db_seq)}")

records =[]
cnt=0
for record in SeqIO.parse(second_db, 'fasta'):
    if record.seq in first_db_seq:
        cnt+=1
        
    else:
        records.append(SeqRecord(seq=record.seq, id=record.id, description=record.description))
    

SeqIO.write(records,out_db,"fasta")

print(f"The number of shared records: {cnt}")
