"""
Remove * from the end of sequence
"""
from Bio import SeqIO
from Bio.SeqRecord import SeqRecord

db_input = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_mipepid\combined_sORFs_mipepid_nonredundant_nonested_newname2.fasta"


out_file = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_mipepid\combined_sORFs_mipepid_nonredundant_nonested_newname2_asterix.fasta"

records = []

for record in SeqIO.parse(db_input, 'fasta'):
    records.append(SeqRecord(seq=record.seq[:-1], id=record.id, description=record.description))
        
  

SeqIO.write(records,out_file,"fasta")