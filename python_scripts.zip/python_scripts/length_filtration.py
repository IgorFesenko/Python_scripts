# фильтрация fasta по длине РНК

from Bio import SeqIO
from Bio.SeqRecord import SeqRecord


# read file
file_input = r'/Users/igorfesenko/Google Диск/lncRNAs_sORFs/combined_set/merged_lncRNAs_locuses.fasta'

# out file
records = []
out_file = r'/Users/igorfesenko/Google Диск/lncRNAs_sORFs/combined_set/merged_lncRNAs_locuses_above200.fasta'

for record in SeqIO.parse(file_input, 'fasta'):
    
    if len(record.seq)>=200:
        records.append(SeqRecord(seq=record.seq, id=record.id, description=record.description))
    

SeqIO.write(records,out_file,"fasta")