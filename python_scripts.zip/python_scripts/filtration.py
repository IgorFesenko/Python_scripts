# Filtration fasta database according to list

from Bio import SeqIO
from Bio.SeqRecord import SeqRecord
import re



# read file
file_input = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_NCBIfinder\merged_lncRNAs_transcripts_filtered_nonredundant.out_30_1_plus"

# out file
records = []
out_file = r'C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_NCBIfinder\merged_sORFs_NCBIfinder_locus_transcripts_db_nucleotide.fa'

# names list
file_filt = r"C:\Users\fesenkoi2\IFESENKO\lncRNAs_sORFs\lncRNAs_sorfs_NCBIfinder\merged_sORFs_NCBIfinder_locus_transcripts_nonredundant_filt_agaisnt_mipepid_nonested_id.txt"


with open(file_filt) as inp:
    lst = [i.strip().split('|')[1] for i in inp.readlines()]
lst = [i.split(':')[0] for i in lst]

print(len(lst))
#print(lst)

for record in SeqIO.parse(file_input, 'fasta'):
    
    name = record.description.split(' ')[1]
    name2 = name.split(':')[0]
    #print(name2)
    if name2 in lst:
        records.append(SeqRecord(seq=record.seq, id=name2, description=record.description))
    
SeqIO.write(records,out_file,"fasta")
