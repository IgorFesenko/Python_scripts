import pandas as pd


df = pd.DataFrame({'Column1':[1,2,3],'Column2':[5,6,7]})

df.to_csv(r'./test_csv.csv')