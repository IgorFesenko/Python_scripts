#!/usr/bin/python
# -*- coding: utf-8 -*-

# TBLASTX parsing on linux mashine

import os
import re
import sys
import getopt

if __name__ == "__main__":
    # Задаём формат входных параметров
    unixOptions = "p:e:"  
    gnuOptions = ["pattern=", "eval="]
    # Получаем строку входных параметров
    fullCmdArguments = sys.argv
    argumentList = fullCmdArguments[1:]

    # Проверяем входные параметры на соответствие формату,
    # заданному в unixOptions и gnuOptions
    try:  
        arguments, values = getopt.getopt(argumentList, unixOptions, gnuOptions)
    except getopt.error as err:  
        print (str(err))
        sys.exit(2)      # Прерываем выполнение, если входные параметры некорректны

    # Считываем значения из строки входных параметров
    pattern = ''
    evalue = ''
      
    for currentArgument, currentValue in arguments:  
        if currentArgument in ("-p", "--pattern"):
            pattern = currentValue                                   
        elif currentArgument in ("-e", "--eval"):
            evalue = currentValue
       

    # creating the list of files
    files = os.listdir(r'./')
    files_lst = [i for i in files if re.findall(pattern,i)]

    for file in files_lst:
        print('running..',file)
        os.system("python3 ./parser_tblastx2.py --file {} -evalue {} &".format(file,evalue))
     